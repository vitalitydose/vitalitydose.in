
const TOOL_CONFIG = {
  'bmi-calculator': {
    title: 'BMI Calculator',
    fields: ['sex', 'age', 'heightCm', 'weightKg'],
    calc: ({ heightCm, weightKg }) => {
      const h = Number(heightCm) / 100;
      const bmi = Number(weightKg) / (h * h);
      let category = 'Obesity';
      if (bmi < 18.5) category = 'Underweight';
      else if (bmi < 25) category = 'Normal range';
      else if (bmi < 30) category = 'Overweight';
      return {
        summary: `Your BMI is ${bmi.toFixed(1)} (${category}).`,
        details: {
          'BMI': bmi.toFixed(1),
          'Category': category
        }
      };
    }
  },
  'tdee-calculator': {
    title: 'TDEE Calculator',
    fields: ['sex', 'age', 'heightCm', 'weightKg', 'activity'],
    calc: ({ sex, age, heightCm, weightKg, activity }) => {
      const w = Number(weightKg), h = Number(heightCm), a = Number(age);
      const bmr = sex === 'female'
        ? (10 * w) + (6.25 * h) - (5 * a) - 161
        : (10 * w) + (6.25 * h) - (5 * a) + 5;
      const mult = Number(activity);
      const tdee = bmr * mult;
      return {
        summary: `Estimated maintenance calories: ${Math.round(tdee)} kcal/day.`,
        details: {
          'BMR': Math.round(bmr),
          'TDEE': Math.round(tdee),
          'Fat loss target': Math.round(tdee - 350),
          'Muscle gain target': Math.round(tdee + 250)
        }
      };
    }
  },
  'macros-calculator': {
    title: 'Macros Calculator',
    fields: ['weightKg', 'calories', 'goal'],
    calc: ({ weightKg, calories, goal }) => {
      const kcal = Number(calories);
      const weight = Number(weightKg);
      const protein = Math.max(weight * 1.8, 90);
      const fat = goal === 'fat-loss' ? weight * 0.8 : weight * 1.0;
      const proteinKcal = protein * 4;
      const fatKcal = fat * 9;
      const carbs = Math.max((kcal - proteinKcal - fatKcal) / 4, 0);
      return {
        summary: `Starter macros for ${goal.replace('-', ' ')}.`,
        details: {
          'Protein (g)': Math.round(protein),
          'Carbs (g)': Math.round(carbs),
          'Fat (g)': Math.round(fat),
          'Calories': Math.round(kcal)
        }
      };
    }
  },
  'body-fat-calculator': {
    title: 'Body Fat Calculator',
    fields: ['sex', 'heightCm', 'neckCm', 'waistCm', 'hipCm'],
    calc: ({ sex, heightCm, neckCm, waistCm, hipCm }) => {
      const h = Number(heightCm), n = Number(neckCm), w = Number(waistCm), hip = Number(hipCm || 0);
      let bf;
      if (sex === 'female') {
        bf = 495 / (1.29579 - 0.35004 * Math.log10(w + hip - n) + 0.22100 * Math.log10(h)) - 450;
      } else {
        bf = 495 / (1.0324 - 0.19077 * Math.log10(w - n) + 0.15456 * Math.log10(h)) - 450;
      }
      return {
        summary: `Estimated body fat: ${bf.toFixed(1)}%.`,
        details: { 'Body fat %': bf.toFixed(1) }
      };
    }
  },
  'ideal-weight-calculator': {
    title: 'Ideal Weight Calculator',
    fields: ['sex', 'heightCm'],
    calc: ({ sex, heightCm }) => {
      const inches = Number(heightCm) / 2.54;
      const over5 = Math.max(inches - 60, 0);
      const devine = sex === 'female' ? 45.5 + 2.3 * over5 : 50 + 2.3 * over5;
      const robinson = sex === 'female' ? 49 + 1.7 * over5 : 52 + 1.9 * over5;
      const miller = sex === 'female' ? 53.1 + 1.36 * over5 : 56.2 + 1.41 * over5;
      return {
        summary: `Healthy-weight formulas give a range, not a verdict.`,
        details: {
          'Devine': `${devine.toFixed(1)} kg`,
          'Robinson': `${robinson.toFixed(1)} kg`,
          'Miller': `${miller.toFixed(1)} kg`
        }
      };
    }
  }
};

function createReportBlob({ title, summary, details }) {
  const now = new Date();
  const rows = Object.entries(details)
    .map(([k, v]) => `<tr><th style="text-align:left;padding:8px;border-bottom:1px solid #ddd">${k}</th><td style="padding:8px;border-bottom:1px solid #ddd">${v}</td></tr>`)
    .join('');
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${title} Report</title></head>
  <body style="font-family:Arial,sans-serif;padding:24px;color:#14312c">
  <h1>${title} Report</h1><p>Generated on ${now.toLocaleString()}</p><p>${summary}</p>
  <table style="border-collapse:collapse;width:100%;max-width:640px">${rows}</table></body></html>`;
  return new Blob([html], { type: 'text/html' });
}

document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('[data-tool-form]');
  const resultBox = document.querySelector('[data-tool-result]');
  const reportBtn = document.querySelector('[data-download-report]');
  if (!form || !resultBox) return;

  const toolKey = form.dataset.tool;
  const config = TOOL_CONFIG[toolKey];
  let latest = null;

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    try {
      latest = config.calc(data);
      resultBox.innerHTML = `<p><strong>${latest.summary}</strong></p><div class="table-like">${
        Object.entries(latest.details).map(([k, v]) => `<div class="row"><span>${k}</span><strong>${v}</strong></div>`).join('')
      }</div>`;
      if (reportBtn) reportBtn.hidden = false;
    } catch (error) {
      resultBox.innerHTML = `<p><strong>Unable to calculate.</strong> Please review your inputs.</p>`;
    }
  });

  reportBtn?.addEventListener('click', () => {
    if (!latest) return;
    const blob = createReportBlob({
      title: config.title,
      summary: latest.summary,
      details: latest.details
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${toolKey}-report.html`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
});
