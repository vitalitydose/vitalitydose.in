
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('[data-menu-toggle]');
  const menu = document.querySelector('[data-menu]');
  if (toggle && menu) {
    toggle.addEventListener('click', () => menu.classList.toggle('open'));
  }

  const year = document.querySelector('[data-year]');
  if (year) year.textContent = new Date().getFullYear();

  document.querySelectorAll('[data-copy-url]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(window.location.href);
        btn.textContent = 'Link copied';
        setTimeout(() => (btn.textContent = 'Copy page link'), 1800);
      } catch {
        btn.textContent = 'Copy failed';
      }
    });
  });

  const filtersRoot = document.querySelector('[data-product-filters]');
  if (filtersRoot) {
    const cards = [...document.querySelectorAll('[data-product-card]')];
    const searchInput = filtersRoot.querySelector('input[name="q"]');
    const selectInput = filtersRoot.querySelector('select[name="category"]');

    const apply = () => {
      const q = (searchInput?.value || '').trim().toLowerCase();
      const category = selectInput?.value || '';
      cards.forEach((card) => {
        const text = card.dataset.search || '';
        const cat = card.dataset.category || '';
        const match = (!q || text.includes(q)) && (!category || category === cat);
        card.hidden = !match;
      });
    };

    searchInput?.addEventListener('input', apply);
    selectInput?.addEventListener('change', apply);
  }
});
